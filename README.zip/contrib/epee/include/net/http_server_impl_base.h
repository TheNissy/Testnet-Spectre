// Copyright (c) 2006-2013, Andrey N. Sabelnikov, www.sabelnikov.net
// All rights reserved.
// 
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:
// * Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
// * Redistributions in binary form must reproduce the above copyright
// notice, this list of conditions and the following disclaimer in the
// documentation and/or other materials provided with the distribution.
// * Neither the name of the Andrey N. Sabelnikov nor the
// names of its contributors may be used to endorse or promote products
// derived from this software without specific prior written permission.
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
// DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER  BE LIABLE FOR ANY
// DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
// (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
// LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
// ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// 




#pragma once 


#include <boost/thread.hpp>
#include <boost/bind/bind.hpp>

#include "cryptonote_config.h"
#include "net/abstract_tcp_server2.h"
#include "http_protocol_handler.h"
#include "net/http_server_handlers_map2.h"

#undef MONERO_DEFAULT_LOG_CATEGORY
#define MONERO_DEFAULT_LOG_CATEGORY "net.http"

namespace epee
{

  template<class t_child_class, class t_connection_context = epee::net_utils::connection_context_base>
  class http_server_impl_base: public net_utils::http::i_http_server_handler<t_connection_context>,
                                      net_utils::i_connection_limit
  {

  public:
    http_server_impl_base()
        : m_net_server(epee::net_utils::e_connection_type_RPC)
    {}

    explicit http_server_impl_base(boost::asio::io_context& external_io_service)
        : m_net_server(external_io_service)
    {}

    bool init(std::function<void(size_t, uint8_t*)> rng, const std::string& bind_port = "0", const std::string& bind_ip = "0.0.0.0",
      const std::string& bind_ipv6_address = "::", bool use_ipv6 = false, bool require_ipv4 = true,
      std::vector<std::string> access_control_origins = std::vector<std::string>(),
      boost::optional<net_utils::http::login> user = boost::none,
      net_utils::ssl_options_t ssl_options = net_utils::ssl_support_t::e_ssl_support_autodetect,
      const std::size_t max_public_ip_connections = DEFAULT_RPC_MAX_CONNECTIONS_PER_PUBLIC_IP,
      const std::size_t max_private_ip_connections = DEFAULT_RPC_MAX_CONNECTIONS_PER_PRIVATE_IP,
      const std::size_t max_connections = DEFAULT_RPC_MAX_CONNECTIONS,
      const std::size_t response_soft_limit = DEFAULT_RPC_SOFT_LIMIT_SIZE)
    {
      if (max_connections < max_public_ip_connections)
        throw std::invalid_argument{"Max public IP connections cannot be more than max connections"};
      if (max_connections < max_private_ip_connections)
        throw std::invalid_argument{"Max private IP connections cannot be more than max connections"};

      //set self as callback handler
      m_net_server.get_config_object().m_phandler = static_cast<t_child_class*>(this);
      m_net_server.get_config_object().rng = std::move(rng);

      //here set folder for hosting requests
      m_net_server.get_config_object().m_folder = "";

      //set access control allow origins if configured
      std::sort(access_control_origins.begin(), access_control_origins.end());
      m_net_server.get_config_object().m_access_control_origins = std::move(access_control_origins);

      m_net_server.get_config_object().m_user = std::move(user);
      m_net_server.get_config_object().m_max_public_ip_connections = max_public_ip_connections;
      m_net_server.get_config_object().m_max_private_ip_connections = max_private_ip_connections;
      m_net_server.get_config_object().m_max_connections = max_connections;
      m_net_server.set_response_soft_limit(response_soft_limit);
      m_net_server.set_connection_limit(this);

      MGINFO("Binding on " << bind_ip << " (IPv4):" << bind_port);
      if (use_ipv6)
      {
        MGINFO("Binding on " << bind_ipv6_address << " (IPv6):" << bind_port);
      }
      bool res = m_net_server.init_server(bind_port, bind_ip, bind_port, bind_ipv6_address, use_ipv6, require_ipv4, std::move(ssl_options));
      if(!res)
      {
        LOG_ERROR("Failed to bind server");
        return false;
      }
      return true;
    }

    bool run(size_t threads_count, bool wait = true)
    {
      //go to loop
      MINFO("Run net_service loop (" << threads_count << " threads)...");
      if(!m_net_server.run_server(threads_count, wait))
      {
        LOG_ERROR("Failed to run net tcp server!");
      }

      if(wait)
        MINFO("net_service loop stopped.");
      return true;
    }

    bool deinit()
    {
      return m_net_server.deinit_server();
    }

    bool timed_wait_server_stop(uint64_t ms)
    {
      return m_net_server.timed_wait_server_stop(ms);
    }

    bool send_stop_signal()
    {
      m_net_server.send_stop_signal();
      return true;
    }

    int get_binded_port()
    {
      return m_net_server.get_binded_port();
    }

    long get_connections_count() const
    {
      return m_net_server.get_connections_count();
    }

  protected: 

    virtual bool is_host_limit(const net_utils::network_address& na) override final
    {
      auto& config = m_net_server.get_config_object();
      CRITICAL_REGION_LOCAL(config.m_lock);
      if (config.m_max_connections <= config.m_connection_count)
        return true;

      const bool is_private = na.is_loopback() || na.is_local();
      const auto elem = config.m_connections.find(na.host_str());
      if (elem != config.m_connections.end())
      {
        if (is_private)
          return config.m_max_private_ip_connections <= elem->second;
        else
          return config.m_max_public_ip_connections <= elem->second;
      }
      return false;
    }

    net_utils::boosted_tcp_server<net_utils::http::http_custom_handler<t_connection_context> > m_net_server;
  };
}
