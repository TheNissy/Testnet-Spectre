﻿# AppKeys Gateway Integration (Monero Wallet RPC)

This fork adds AppKeys spend authorization directly into `monero-wallet-rpc` for:
- `transfer`
- `transfer_split`
- `sweep_all`

## Enable

Run wallet RPC with:

```bash
--appkeys-enforce-spend-gateway \
--appkeys-policy-file=/path/to/policy.json \
--appkeys-replay-window-seconds=120
```

When enabled, spend RPC requests without valid AppKeys metadata are rejected with:

`ERROR: DIRECT_WALLET_ACCESS_BLOCKED_BY_APPKEYS`

## Request fields

Spend methods now accept an `appkeys` object:

```json
"appkeys": {
  "app_key_id": "poker-app-key",
  "session_token": "session-token-1",
  "request_nonce": "nonce-123",
  "request_timestamp": 1717000000,
  "request_signature": "hex-signature"
}
```

## Signature format

Expected signature is:

`hex(cn_fast_hash(hmac_secret + ":" + session_secret + ":" + payload))`

Where payload is:

`app_key_id:session_token:request_nonce:request_timestamp:account_index:amount_total:is_sweep_all[:dest_addr:dest_amount ...]`

## Policy file

Use `contrib/appkeys/policy.example.json` as a template.

## Reload policy at runtime

Call JSON-RPC method:

`appkeys_reload_policy`

This reloads profiles and sessions from the configured policy file.

## monero-wallet-cli AppKeys controls

`monero-wallet-cli` now includes an `appkeys` command with subcommands:

- `appkeys load_policy <path>`
- `appkeys save_policy [path]`
- `appkeys reload`
- `appkeys status`
- `appkeys list`
- `appkeys create_key <app_key_id> <wallet_address> <spend_limit_per_tx> <daily_limit> <total_allocation> [allowed=<addr1,addr2>] [blocked=<addr1,addr2>]`
- `appkeys revoke_key <app_key_id> <0|1>`
- `appkeys create_session <session_token> <app_key_id> <session_secret> <expires_at_unix>`
- `appkeys revoke_session <session_token> <0|1>`
- `appkeys use_session <session_token>`
- `appkeys clear_session`
- `appkeys enforce_cli <0|1>`

When `appkeys enforce_cli 1` is enabled, spend commands (`transfer`, `sweep_all`, `sweep_account`, `sweep_below`, `sweep_single`) are blocked unless an active, valid AppKeys session is selected and policy checks pass.
